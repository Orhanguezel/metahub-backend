import type {
  GatewayAdapter, CreateCheckoutInput, CreateCheckoutOutput,
  CaptureInput, CaptureOutput, RefundInput, RefundOutput,
  WebhookEvent, GatewayCredentials
} from "../../types/gateway.types";
import type { Request } from "express";

export class IyzicoAdapter implements GatewayAdapter {
  readonly name = "iyzico" as const;

  async createCheckout(_input: CreateCheckoutInput): Promise<CreateCheckoutOutput> {
    const ref = `iy_${Date.now()}`;
    return { providerRef: ref, hostedUrl: `https://iyzico.mock/pay/${ref}` };
  }

  async capture(_input: CaptureInput): Promise<CaptureOutput> {
    return { ok: true, status: "succeeded" };
  }

  async refund(_input: RefundInput): Promise<RefundOutput> {
    return { ok: true, status: "succeeded", refundRef: `iy_rf_${Date.now()}` };
  }

  async parseWebhook(req: Request, _creds: GatewayCredentials): Promise<WebhookEvent> {
    const b = req.body || {};
    // b.status === "success" → payment.succeeded
    // iade: b.eventType === "REFUND_SUCCEEDED"/"REFUND_FAILED"
    const type =
      b?.eventType === "REFUND_SUCCEEDED" ? "refund.succeeded" :
        b?.eventType === "REFUND_FAILED" ? "refund.failed" :
          (b?.status === "success" ? "payment.succeeded" : "payment.failed");

    return {
      type,
      providerRef: String(b?.paymentId || b?.token || `iy_${Date.now()}`),
      refundRef: b?.refundId ? String(b.refundId) : undefined,
      amount: b?.paidPrice != null ? Math.round(Number(b.paidPrice) * 100) : undefined,
      currency: (b?.currency || "TRY").toUpperCase(),
      method: "card",
      raw: b,
    };
  }
}
