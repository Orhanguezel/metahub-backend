import type {
  GatewayAdapter, CreateCheckoutInput, CreateCheckoutOutput,
  CaptureInput, CaptureOutput, RefundInput, RefundOutput,
  WebhookEvent, GatewayCredentials
} from "../../types/gateway.types";
import type { Request } from "express";

export class CraftgateAdapter implements GatewayAdapter {
  readonly name = "craftgate" as const;

  async createCheckout(_input: CreateCheckoutInput): Promise<CreateCheckoutOutput> {
    const ref = `cg_${Date.now()}`;
    return { providerRef: ref, hostedUrl: `https://checkout.craftgate.io/${ref}` };
  }

  async capture(_input: CaptureInput): Promise<CaptureOutput> {
    return { ok: true, status: "succeeded" };
  }

  async refund(_input: RefundInput): Promise<RefundOutput> {
    return { ok: true, status: "succeeded", refundRef: `cg_rf_${Date.now()}` };
  }

  async parseWebhook(req: Request, _creds: GatewayCredentials): Promise<WebhookEvent> {
    const b = req.body || {};
    // eventType: PAYMENT_SUCCEEDED | PAYMENT_FAILED | REFUND_SUCCEEDED | REFUND_FAILED
    const map: Record<string, WebhookEvent["type"]> = {
      PAYMENT_SUCCEEDED: "payment.succeeded",
      PAYMENT_FAILED: "payment.failed",
      REFUND_SUCCEEDED: "refund.succeeded",
      REFUND_FAILED: "refund.failed",
    };
    const type = map[b?.eventType] || "payment.processing";
    return {
      type,
      providerRef: String(b?.paymentId || b?.transactionId || `cg_${Date.now()}`),
      refundRef: b?.refundId ? String(b.refundId) : undefined,
      amount: b?.paidPrice != null ? Math.round(Number(b.paidPrice) * 100) : undefined,
      currency: (b?.currency || "TRY").toUpperCase(),
      method: "card",
      raw: b,
    };
  }
}
