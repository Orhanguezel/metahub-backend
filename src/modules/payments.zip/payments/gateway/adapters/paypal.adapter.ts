import type {
  GatewayAdapter, CreateCheckoutInput, CreateCheckoutOutput,
  CaptureInput, CaptureOutput, RefundInput, RefundOutput,
  WebhookEvent, GatewayCredentials
} from "../../types/gateway.types";
import type { Request } from "express";

export class PaypalAdapter implements GatewayAdapter {
  readonly name = "paypal" as const;

  async createCheckout(_input: CreateCheckoutInput): Promise<CreateCheckoutOutput> {
    const providerRef = `pp_${Date.now()}`;
    return { providerRef, hostedUrl: `https://paypal.mock/approve/${providerRef}` };
  }

  async capture(_input: CaptureInput): Promise<CaptureOutput> {
    return { ok: true, status: "succeeded" };
  }

  async refund(_input: RefundInput): Promise<RefundOutput> {
    return { ok: true, status: "succeeded", refundRef: `pp_rf_${Date.now()}` };
  }

  async parseWebhook(req: Request, _creds: GatewayCredentials): Promise<WebhookEvent> {
    const b = req.body || {};
    const et = String(b?.event_type || "").toUpperCase();

    // Örnek: PAYMENT.CAPTURE.COMPLETED (success), PAYMENT.SALE.REFUNDED (refund)
    if (et === "PAYMENT.SALE.REFUNDED" || et === "PAYMENT.CAPTURE.REFUNDED") {
      const amountMajor = Number(b?.resource?.amount?.total || b?.resource?.amount?.value || 0);
      const currency = (b?.resource?.amount?.currency || b?.resource?.amount?.currency_code || "USD").toUpperCase();
      return {
        type: "refund.succeeded",
        providerRef: String(b?.resource?.sale_id || b?.resource?.capture_id || b?.resource?.parent_payment || "pp_tx"),
        refundRef: String(b?.resource?.id || `pp_rf_${Date.now()}`),
        amount: Math.round(amountMajor * 100),
        currency,
        method: "card",
        raw: b,
      };
    }

    const amountMajor = Number(b?.resource?.amount?.value || b?.resource?.amount?.total || 0);
    const currency = (b?.resource?.amount?.currency || b?.resource?.amount?.currency_code || "USD").toUpperCase();

    return {
      type: et.endsWith(".COMPLETED") ? "payment.succeeded" : "payment.processing",
      providerRef: String(b?.resource?.id || "pp_tx"),
      amount: Math.round(amountMajor * 100),
      currency,
      method: "card",
      raw: b,
    };
  }
}
