import type {
  GatewayAdapter, CreateCheckoutInput, CreateCheckoutOutput,
  CaptureInput, CaptureOutput, RefundInput, RefundOutput,
  WebhookEvent, GatewayCredentials
} from "../../types/gateway.types";
import type { Request } from "express";

export class PaycellAdapter implements GatewayAdapter {
  readonly name = "paycell" as const;

  async createCheckout(_input: CreateCheckoutInput): Promise<CreateCheckoutOutput> {
    const ref = `pc_${Date.now()}`;
    return {
      providerRef: ref,
      hostedUrl: `https://paycell.mock/pay/${ref}`,
      payload: { method: "wallet" }
    };
  }

  async capture(_input: CaptureInput): Promise<CaptureOutput> {
    return { ok: true, status: "succeeded" };
  }

  async refund(_input: RefundInput): Promise<RefundOutput> {
    return { ok: true, status: "processing", refundRef: `pc_rf_${Date.now()}` };
  }

  async parseWebhook(req: Request, _creds: GatewayCredentials): Promise<WebhookEvent> {
    const b = req.body || {};
    const isRefund = b?.eventType === "REFUND_SUCCEEDED" || b?.eventType === "REFUND_FAILED";
    const type =
      b?.eventType === "REFUND_SUCCEEDED" ? "refund.succeeded" :
        b?.eventType === "REFUND_FAILED" ? "refund.failed" :
          ((b?.result?.code === "0" || b?.status === "SUCCESS") ? "payment.succeeded" : "payment.failed");

    return {
      type,
      providerRef: String(b?.transactionId || b?.paymentId || `pc_${Date.now()}`),
      refundRef: isRefund ? (String(b?.refundId || "") || undefined) : undefined,
      // Paycell bazen minor unit döndürür; burada **minor** kabul ediyoruz.
      amount: b?.amount != null ? Number(b.amount) : undefined,
      currency: (b?.currency || "TRY").toUpperCase(),
      method: "wallet",
      raw: b,
    };
  }
}
