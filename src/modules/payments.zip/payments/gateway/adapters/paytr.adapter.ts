import type {
  GatewayAdapter, CreateCheckoutInput, CreateCheckoutOutput,
  CaptureInput, CaptureOutput, RefundInput, RefundOutput,
  WebhookEvent, GatewayCredentials
} from "../../types/gateway.types";
import type { Request } from "express";

export class PaytrAdapter implements GatewayAdapter {
  readonly name = "paytr" as const;

  async createCheckout(_input: CreateCheckoutInput): Promise<CreateCheckoutOutput> {
    const ref = `pt_${Date.now()}`;
    return { providerRef: ref, hostedUrl: `https://www.paytr.com/odeme/guvenli/${ref}` };
  }

  async capture(_input: CaptureInput): Promise<CaptureOutput> {
    return { ok: true, status: "succeeded" };
  }

  async refund(_input: RefundInput): Promise<RefundOutput> {
    return { ok: true, status: "processing", refundRef: `pt_rf_${Date.now()}` };
  }

  async parseWebhook(req: Request, _creds: GatewayCredentials): Promise<WebhookEvent> {
    const body = req.body || {};
    // TODO: PayTR hash doğrulama
    return {
      type: body?.status === "success" ? "payment.succeeded" : "payment.failed",
      providerRef: body?.merchant_oid ? String(body.merchant_oid) : `pt_${Date.now()}`,
      amount: Number(body?.total_amount || 0), // minor unit
      currency: "TRY",
      method: "card",
      raw: body,
    };
  }
}
