// src/modules/payments/gateways.admin.validation.ts

import { body, param, query } from "express-validator";
import { validateRequest } from "@/core/middleware/validateRequest";

const PROVIDERS = ["stripe","paypal","iyzico","paytr","papara","paycell","craftgate","manual"];

export const validateGatewayId = [
  param("id").isMongoId(),
  validateRequest,
];

export const validateGatewayCreate = [
  body("provider").notEmpty().isIn(PROVIDERS),
  body("title").optional().isString(),
  body("isActive").optional().isBoolean(),
  body("testMode").optional().isBoolean(),
  body("allowedMethods").optional().isArray(),
  body("credentials").optional().isObject(),
  validateRequest,
];

export const validateGatewayUpdate = [
  body("title").optional().isString(),
  body("isActive").optional().isBoolean(),
  body("testMode").optional().isBoolean(),
  body("allowedMethods").optional().isArray(),
  body("credentials").optional().isObject(),
  validateRequest,
];

export const validateGatewayList = [
  query("provider").optional().isIn(PROVIDERS),
  query("isActive").optional().toBoolean().isBoolean(),
  validateRequest,
];

export const validateGatewayTest = [
  param("id").isMongoId(),
  validateRequest,
];
