// src/modules/payments/gateways.admin.routes.ts

import express from "express";
import { authenticate, authorizeRoles } from "@/core/middleware/auth/authMiddleware";
import {
  listGateways,
  getGateway,
  createGateway,
  updateGateway,
  deleteGateway,
  testGateway,
} from "./gateways.admin.controller";
import {
  validateGatewayList,
  validateGatewayId,
  validateGatewayCreate,
  validateGatewayUpdate,
  validateGatewayTest,
} from "./gateways.admin.validation";

const router = express.Router();

router.use(authenticate, authorizeRoles("admin", "moderator"));

router.get("/", validateGatewayList, listGateways);
router.get("/:id", validateGatewayId, getGateway);
router.post("/", validateGatewayCreate, createGateway);
router.put("/:id", validateGatewayId, validateGatewayUpdate, updateGateway);
router.delete("/:id", validateGatewayId, deleteGateway);
router.post("/:id/test", validateGatewayTest, testGateway);

export default router;
