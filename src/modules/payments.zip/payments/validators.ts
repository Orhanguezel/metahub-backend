// src/modules/payments/validators.ts
import { body } from "express-validator";

/** Desteklenen ödeme sağlayıcıları */
export const PROVIDERS = [
  "stripe","paypal","iyzico","paytr","craftgate","papara","paycell","manual"
] as const;

/** number → integer minor units (ör. 1990.66 → 1991) */
const toMinorInt = (v: unknown) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return v;   // bir sonraki validator yakalar
  return Math.round(n);
};

/** Checkout body validators (minor units + temel alanlar) */
export const createCheckoutValidators = [
  // Temel alanlar
  body("provider").isIn(PROVIDERS as unknown as string[]),
  body("orderId").optional().isMongoId(),
  body("currency")
    .optional()
    .isString()
    .isLength({ min: 3, max: 3 })
    .bail()
    .customSanitizer((s) => String(s).toUpperCase()),
  body("method").optional().isIn(["card","wallet","bank_transfer","cash","other"]),
  body("ui_mode").optional().isIn(["embedded","hosted","elements"]),

  // amount: OPSIYONEL — orderId varsa BE zaten sipariş tutarını kullanır
  // Minor int’e yuvarla + ≥1
  body("amount")
    .optional()
    .customSanitizer(toMinorInt)
    .isInt({ min: 1 })
    .withMessage("amount must be a positive integer in minor units"),

  // items: opsiyonel liste
  body("items").optional().isArray(),

  // items[*].unitAmount: minor int’e yuvarla + ≥1
  body("items.*.unitAmount")
    .optional()
    .customSanitizer(toMinorInt)
    .isInt({ min: 1 })
    .withMessage("items[].unitAmount must be integer minor units"),

  // items[*].qty: minor int (adet) + ≥1
  body("items.*.qty")
    .optional()
    .customSanitizer(toMinorInt)
    .isInt({ min: 1 })
    .withMessage("items[].qty must be a positive integer"),

  // Müşteri e-postası (varsa) temel kontrol
  body("customer.email")
    .optional()
    .isEmail()
    .withMessage("customer.email must be a valid email"),
];
