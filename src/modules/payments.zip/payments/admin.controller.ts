import { Request, Response } from "express";
import asyncHandler from "express-async-handler";
import { getTenantModels } from "@/core/middleware/tenant/getTenantModels";
import { normalizeCreds } from "./gateway";

const PROVIDERS = ["stripe","paypal","iyzico","paytr","craftgate","papara","paycell","manual"] as const;

export const upsertGateway = asyncHandler(async (req: Request, res: Response) => {
  const { PaymentGateway } = await getTenantModels(req);
  const { provider, isActive, mode, credentials, testMode } = req.body as {
    provider: typeof PROVIDERS[number];
    isActive?: boolean;
    mode?: "test" | "live";
    testMode?: boolean; // backward compat
    credentials?: Record<string, any>;
  };

  if (!provider || !PROVIDERS.includes(provider)) {
    res.status(400).json({ success: false, message: "invalid_provider" });
    return;
  }

  const normalizedMode =
    typeof testMode === "boolean" ? (testMode ? "test" : "live") :
    (mode === "test" || mode === "live" ? mode : undefined);

  const update: any = {};
  if (typeof isActive === "boolean") update.isActive = isActive;
  if (normalizedMode) update.mode = normalizedMode;
  if (credentials) update.credentials = normalizeCreds(credentials);

  const doc = await PaymentGateway.findOneAndUpdate(
    { tenant: req.tenant, provider },
    { $set: update, $setOnInsert: { tenant: req.tenant, provider } },
    { upsert: true, new: true }
  );

  res.status(200).json({ success: true, data: doc });
});

export const listGateways = asyncHandler(async (req: Request, res: Response) => {
  const { PaymentGateway } = await getTenantModels(req);
  const items = await PaymentGateway.find({ tenant: req.tenant }).sort({ provider: 1 }).lean();
  res.json({ success: true, data: items });
});
