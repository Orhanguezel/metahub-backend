// src/modules/payments/public.routes.ts
import express from "express";
import {
  createCheckoutIntent,
  handleWebhook,
  capturePayment,
  providerRefund,
} from "./intents/intent.controller";
import { validateRequest } from "@/core/middleware/validateRequest";
import { createCheckoutValidators } from "./validators";
import { body, param } from "express-validator";

const PROVIDERS = ["stripe","paypal","iyzico","paytr","craftgate","papara","paycell","manual"] as const;

const router = express.Router();

/** Webhook için raw body gerekir (imza doğrulaması olan sağlayıcılar için) */
const rawJsonFallback: express.RequestHandler = (req, _res, next) => {
  if (Buffer.isBuffer(req.body)) {
    try { req.body = JSON.parse(req.body.toString("utf8")); } catch { /* ignore */ }
  }
  next();
};

/**
 * (NEW) POST /api/.../payments/intents/checkout
 * Body: { provider, orderId?, amount?, currency?, method?, returnUrl?, cancelUrl?, customer?, items?, metadata?, ui_mode? }
 * Not: ui_mode istersen body’nin üstünde de gönderebilirsin; metadata.ui_mode da desteklenir.
 */
router.post(
  "/checkout",
  ...createCheckoutValidators,
  validateRequest,
  createCheckoutIntent
);

/**
 * (NEW) POST /api/.../payments/intents/webhooks/:provider
 * İmza doğrulaması için raw body.
 */
router.post(
  "/webhooks/:provider",
  param("provider").isIn(PROVIDERS as unknown as string[]),
  validateRequest,
  express.raw({ type: "*/*" }),
  rawJsonFallback,
  handleWebhook
);

/** (NEW) POST /api/.../payments/intents/capture */
router.post(
  "/capture",
  body("provider").isIn(PROVIDERS as unknown as string[]),
  body("providerRef").notEmpty(),
  body("amount").optional().isInt({ min: 1 }),
  validateRequest,
  capturePayment
);

/** (NEW) POST /api/.../payments/intents/refund/provider */
router.post(
  "/refund/provider",
  body("provider").isIn(PROVIDERS as unknown as string[]),
  body("providerRef").notEmpty(),
  body("amount").optional().isInt({ min: 1 }),
  body("reason").optional().isString(),
  validateRequest,
  providerRefund
);

export default router;
