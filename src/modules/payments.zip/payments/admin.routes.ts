// src/modules/payments/admin.routes.ts

import express from "express";
import { authenticate, authorizeRoles } from "@/core/middleware/auth/authMiddleware";
import { upsertGateway, listGateways } from "./admin.controller";
import { body } from "express-validator";
import { validateRequest } from "@/core/middleware/validateRequest";

const router = express.Router();
router.use(authenticate, authorizeRoles("admin", "moderator"));

router.get("/", listGateways);

router.post(
  "/",
  body("provider").isIn(["stripe","paypal","iyzico","paytr","craftgate","papara","paycell","manual"]),
  body("mode").optional().isIn(["test","live"]),
  body("testMode").optional().isBoolean(),
  body("isActive").optional().isBoolean(),
  body("credentials").optional().isObject(),
  validateRequest,
  upsertGateway
);

export default router;
